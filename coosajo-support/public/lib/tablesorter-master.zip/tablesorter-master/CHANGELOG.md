Change log moved to the [wiki documentation pages](https://github.com/Mottie/tablesorter/wiki/Changes).
